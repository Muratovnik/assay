#!/usr/bin/env python3
"""Preserve a completed study as exact-byte content-addressed evidence; stdlib only."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import zipfile
import zlib

SCHEMA = "assay-exact-byte-evidence-v1"
ARCHIVE_ENCODING = {"method": "ZIP_DEFLATED", "level": 9, "python_version": sys.version.split()[0], "zlib_compile_version": zlib.ZLIB_VERSION, "zlib_runtime_version": zlib.ZLIB_RUNTIME_VERSION}
MAX_VOLUME_BYTES = 11_000_000
SHA = re.compile(r"[0-9a-f]{64}\Z")
WORDLIM = re.compile(r"\[wordlim\s*:?\s*\d+\]", re.I)
WEBREF = re.compile(r"【turn[^】]*(?:view|search)\d+】")
URL = re.compile(r"https?://[^\s<>\"'\)]+")
ENV_PARTS = {".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox", "node_modules", ".cache", "site-packages", "dist-packages", ".git"}
AUTH_PARTS = {".aws", ".ssh", ".gnupg", ".azure", ".kube", ".credentials", "browser-profile", "chrome-profile", "chromium-profile", "firefox-profile"}
AUTH_NAMES = {"auth.json", "credentials.json", "credentials", ".netrc", "cookies.sqlite", "Cookies", "Login Data", "Local State"}


def canonical_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_unique_json(data):
    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("Ambiguous JSON: duplicate object key " + repr(key))
            value[key] = item
        return value
    return json.loads(data, object_pairs_hook=unique_object)


def safe_logical(value):
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise ValueError("Unsafe logical path")
    pieces = value.split("/")
    if value.startswith("/") or any(p in {"", ".", ".."} or ":" in p for p in pieces):
        raise ValueError("Unsafe logical path: " + repr(value))
    if any(ord(c) < 32 for c in value):
        raise ValueError("Control character in logical path")
    return value


def absolute_safe(value):
    p = Path(os.path.abspath(os.fspath(value)))
    if ".." in Path(value).parts:
        raise ValueError("Parent traversal is not allowed: " + str(value))
    for q in (p, *p.parents):
        if q.is_symlink():
            raise ValueError("Symlink path is not allowed: " + str(q))
    return p


def regular(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError("Expected a regular file: " + str(path))


def signature(path):
    s = path.stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, stat.S_IMODE(s.st_mode))


def read_exact(path):
    regular(path)
    before = signature(path)
    data = path.read_bytes()
    if signature(path) != before or len(data) != before[2]:
        raise ValueError("File changed while reading: " + str(path))
    return data


def inventory(root, prefix, reserved=()):
    if not stat.S_ISDIR(root.lstat().st_mode):
        raise ValueError("Inventory root must be an existing non-symlink directory: " + str(root))
    def enumeration_error(error):
        raise error
    result = {}
    for directory, dirs, names in os.walk(root, followlinks=False, onerror=enumeration_error):
        dirs.sort()
        names.sort()
        for name in list(dirs):
            q = Path(directory) / name
            if q.is_symlink():
                raise ValueError("Symlink directory is not allowed: " + str(q))
            if q in reserved:
                dirs.remove(name)
        for name in names:
            q = Path(directory) / name
            if q in reserved:
                continue  # Generated outputs are never source candidates, even on a rerun.
            regular(q)
            logical = safe_logical(prefix + "/" + q.relative_to(root).as_posix())
            if logical in result:
                raise ValueError("Duplicate logical path: " + logical)
            result[logical] = q
    return result


def object_record(path):
    data = read_exact(path)
    obj = load_unique_json(data)
    if not isinstance(obj, dict) or not obj:
        raise ValueError("Required record must be a nonempty JSON object: " + str(path))
    return data, obj


def gate(args):
    # No study, packet, case, key, or directory inventory is read before this gate.
    if not args.finalize:
        raise ValueError("--finalize is required; reserved evidence must be exposed and final records ready")
    study = absolute_safe(args.study)
    selection = absolute_safe(args.selection_record)
    final = absolute_safe(args.final_results_record)
    if selection == final:
        raise ValueError("Selection and final-results records must be different files")
    records = {}
    for label, path in (("selection", selection), ("final_results", final)):
        if not path.is_relative_to(study):
            raise ValueError(label + " record must be inside the named study")
        data, _ = object_record(path)
        records[label] = {"logical_path": safe_logical("study/" + path.relative_to(study).as_posix()), "sha256": sha256(data), "bytes": len(data)}
    if not study.is_dir():
        raise ValueError("Study is not a directory")
    return study, records


def header_urls(text):
    # Capture provenance headers, never the page's link list or paragraph contents.
    header = re.split(r"(?m)^L\d+:", text, maxsplit=1)[0][:4096]
    return sorted({u.rstrip(".,;:]}>") for u in URL.findall(header) if len(u) > 10})


def is_web_text(value):
    header = value[:4096]
    return bool(WORDLIM.search(header) or (WEBREF.search(header) and "Content type:" in header and "Source:" in header))


def reviewed_web_captures(data, logical):
    """Load explicit reviewed strings; allow only content-identical diagnostic aliases."""
    registry_data = read_exact(Path(__file__).with_name("reviewed-web-captures.json"))
    registry = load_unique_json(registry_data)
    if not isinstance(registry, dict) or registry.get("schema") != "reviewed-web-capture-overrides-v1" or not isinstance(registry.get("captures"), list):
        raise ValueError("Invalid reviewed web-capture registry")
    digest = sha256(data)
    selected = {}
    for record in registry["captures"]:
        if not isinstance(record, dict):
            raise ValueError("Invalid reviewed web-capture record")
        reviewed_path = safe_logical(record.get("logical_path"))
        expected = record.get("file_sha256")
        strings = record.get("strings")
        if "diagnostics" not in PurePosixPath(reviewed_path).parts or not isinstance(expected, str) or not SHA.fullmatch(expected) or not isinstance(strings, dict) or not strings:
            raise ValueError("Invalid reviewed web-capture binding: " + reviewed_path)
        if logical == reviewed_path and digest != expected:
            raise ValueError("Reviewed web-capture bytes changed; explicit re-review required: " + logical)
        for pointer, capture in strings.items():
            if not isinstance(pointer, str) or not pointer.startswith("/") or not isinstance(capture, dict):
                raise ValueError("Invalid reviewed web-capture pointer: " + reviewed_path)
            hashes = [capture.get("encoded_json_slice_sha256"), capture.get("decoded_utf8_sha256")]
            urls = capture.get("urls")
            if any(not isinstance(value, str) or not SHA.fullmatch(value) for value in hashes) or not isinstance(urls, list) or not urls or any(not isinstance(url, str) or not URL.fullmatch(url) for url in urls):
                raise ValueError("Invalid reviewed web-capture provenance: " + reviewed_path + pointer)
            if digest == expected:
                if pointer in selected:
                    raise ValueError("Ambiguous reviewed web-capture pointer: " + logical + pointer)
                selected[pointer] = {**capture, "urls": sorted(set(urls)), "reviewed_logical_path": reviewed_path, "registry_sha256": sha256(registry_data)}
    return selected


def diagnostic_provenance(data, logical):
    """Remove only confirmed diagnostic web strings; preserve all surrounding bytes."""
    if "diagnostics" not in PurePosixPath(logical).parts:
        return None
    suffix = PurePosixPath(logical).suffix.lower()
    if suffix == ".jsonl":
        pieces, omissions = [], []
        for number, line in enumerate(data.splitlines(keepends=True), 1):
            derived = diagnostic_provenance(line, logical[:-1])
            pieces.append(derived[0] if derived else line)
            if derived:
                omissions.extend({"jsonl_line": number, **row} for row in derived[1])
        return (b"".join(pieces), omissions) if omissions else None
    if suffix not in {".json", ".txt", ".log"}:
        return None  # Raw writer Markdown, source scripts and binary artifacts are exact.
    reviewed = reviewed_web_captures(data, logical) if suffix == ".json" else {}
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    omissions = []
    if suffix != ".json":
        if not is_web_text(text) or not header_urls(text):
            return None
        note = {"original_logical_path": logical, "original_sha256": sha256(data), "bytes": len(data), "urls": header_urls(text), "reason": "Confirmed third-party web capture: page body excluded"}
        return canonical_json(note), [note]
    try:
        obj = load_unique_json(text)
    except json.JSONDecodeError:
        if WORDLIM.search(text):
            raise ValueError("Unparseable diagnostic JSON containing a web marker: " + logical)
        return None
    reviewed_seen = set()
    decoder = json.JSONDecoder()
    spans = []

    def skip(i):
        while i < len(text) and text[i].isspace():
            i += 1
        return i

    def walk(i, value, pointer, command=False, tool_result=False):
        i = skip(i)
        if isinstance(value, dict):
            command = command or ("command" in value and bool({"stdout", "stderr", "exit_code", "expected_exit"} & value.keys()))
            tool_result = tool_result or (isinstance(value.get("content"), list) and ("isError" in value or any(isinstance(v, dict) and v.get("type") == "text" for v in value["content"])))
            i = skip(i + 1)
            while text[i] != "}":
                key, end = decoder.raw_decode(text, i)
                i = skip(end)
                if text[i] != ":":
                    raise ValueError("Invalid JSON object")
                i = walk(i + 1, value[key], pointer + "/" + key.replace("~", "~0").replace("/", "~1"), command, tool_result)
                i = skip(i)
                if text[i] == ",":
                    i = skip(i + 1)
                else:
                    break
            return i + 1
        if isinstance(value, list):
            i = skip(i + 1)
            for n, item in enumerate(value):
                i = walk(i, item, pointer + "/" + str(n), command, tool_result)
                i = skip(i)
                if n + 1 < len(value):
                    i = skip(i + 1)
            return i + 1
        _, end = decoder.raw_decode(text, i)
        reviewed_capture = reviewed.get(pointer)
        if reviewed_capture:
            if not isinstance(value, str) or command or sha256(text[i:end].encode("utf-8")) != reviewed_capture["encoded_json_slice_sha256"] or sha256(value.encode("utf-8")) != reviewed_capture["decoded_utf8_sha256"]:
                raise ValueError("Reviewed web-capture string changed or overlaps local command evidence: " + logical + pointer)
            reviewed_seen.add(pointer)
        # A local source/command receipt stays exact even if it quotes a marker.
        if isinstance(value, str) and not command and (reviewed_capture or (is_web_text(value) and (tool_result or WORDLIM.search(value[:4096])))):
            urls = reviewed_capture["urls"] if reviewed_capture else header_urls(value)
            if not urls:
                raise ValueError("Confirmed web capture has no source URL: " + logical + pointer)
            encoded = text[i:end].encode("utf-8")
            note = {"json_pointer": pointer, "encoded_json_slice_sha256": sha256(encoded), "encoded_json_slice_bytes": len(encoded), "decoded_utf8_sha256": sha256(value.encode("utf-8")), "decoded_utf8_bytes": len(value.encode("utf-8")), "urls": urls, "reason": "Confirmed third-party web capture: page text excluded"}
            if reviewed_capture:
                note["reviewed_capture"] = {"logical_path": reviewed_capture["reviewed_logical_path"], "file_sha256": sha256(data), "registry_sha256": reviewed_capture["registry_sha256"]}
            replacement = json.dumps({"web_capture_provenance": note}, ensure_ascii=True, sort_keys=True).encode("utf-8")
            spans.append((i, end, replacement))
            omissions.append(note)
        return end

    walk(0, obj, "")
    if reviewed_seen != reviewed.keys():
        raise ValueError("Reviewed web-capture pointer missing: " + logical)
    if not spans:
        return None
    pieces = []
    previous = 0
    for start, end, replacement in spans:
        pieces.extend((text[previous:start].encode("utf-8"), replacement))
        previous = end
    pieces.append(text[previous:].encode("utf-8"))
    result = b"".join(pieces)
    load_unique_json(result)  # Structural validation only; never execute retained contents.
    return result, omissions


def publication_parts(value):
    """Distinguish wholly connector envelopes from wrappers with other evidence."""
    if isinstance(value, dict):
        if "content" in value and ("structuredContent" in value or "isError" in value):
            envelope_keys = {"content", "structuredContent", "isError", "_meta"}
            return {"connector"} if value.keys() <= envelope_keys else {"connector", "other"}
        children = value.values()
    elif isinstance(value, list):
        children = value
    else:
        return {"other"}
    kinds = set()
    for child in children:
        kinds.update(publication_parts(child))
    return kinds or {"other"}


def path_exclusion(logical):
    parts = PurePosixPath(logical).parts
    if "project_sources" in parts:
        return "Full private supplied documents in project_sources are outside retained scope"
    if any(p in ENV_PARTS for p in parts):
        return "Environment, dependency cache, or Git metadata excluded"
    if any(p in AUTH_PARTS for p in parts) or parts[-1] in AUTH_NAMES:
        return "Authentication or browser/profile data excluded"
    return None


def native_executable(data):
    if data[:4] in {b"\x7fELF", b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe"}:
        return True
    if data[:4] in {b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca", b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca"} and len(data) >= 8:
        count = int.from_bytes(data[4:8], "big" if data[0] == 0xca else "little")
        return 1 <= count <= 32 and len(data) >= 8 + 20 * count
    if data[:2] == b"MZ" and len(data) >= 64:
        offset = int.from_bytes(data[60:64], "little")
        return data[offset:offset + 4] == b"PE\x00\x00"
    return False


def verify_tree(root, manifest, expected_digest=None, list_shape=False):
    raw, obj = object_record(manifest)
    if expected_digest and sha256(raw) != expected_digest:
        raise ValueError("Immutable manifest hash mismatch: " + str(manifest))
    entries = obj.get("files")
    if list_shape:
        if not isinstance(entries, list):
            raise ValueError("Expected source file list: " + str(manifest))
        expected = {}
        for row in entries:
            rel = safe_logical(row["path"])
            if rel in expected:
                raise ValueError("Duplicate manifest path: " + rel)
            expected[rel] = row["sha256"]
    else:
        if not isinstance(entries, dict):
            raise ValueError("Expected file hash map: " + str(manifest))
        expected = {safe_logical(k): v for k, v in entries.items()}
    if any(not isinstance(v, str) or not SHA.fullmatch(v) for v in expected.values()):
        raise ValueError("Invalid SHA-256 in manifest: " + str(manifest))
    actual = inventory(root, "root")
    actual = {k[5:]: p for k, p in actual.items() if p != manifest}
    if set(actual) != set(expected):
        raise ValueError("Manifest tree mismatch: " + str(manifest))
    for rel, path in actual.items():
        if sha256(read_exact(path)) != expected[rel]:
            raise ValueError("Frozen/source byte mismatch: " + str(path))
    return {"manifest_sha256": sha256(raw), "files_verified": len(expected)}, expected


def bundled_assembler_members():
    """Keep the standalone assembler and its reviewed-capture companion together."""
    script = Path(__file__)
    return {"assemble.py": read_exact(script), "reviewed-web-captures.json": read_exact(script.with_name("reviewed-web-captures.json"))}


def assemble(args):
    study, finalization = gate(args)
    packets_root = absolute_safe(args.packets_root)
    output = absolute_safe(args.output)
    part_value = getattr(args, "part_output", None)
    part_output = absolute_safe(part_value) if part_value is not None else None
    archive_outputs = [output] + ([part_output] if part_output is not None else [])
    index_path = output.with_suffix(".index.json")
    if any(path.suffix.lower() != ".zip" for path in archive_outputs):
        raise ValueError("Output must have .zip extension")
    if part_output is not None and (part_output == output or part_output.parent != output.parent):
        raise ValueError("Second volume must have a distinct name in the primary output directory")
    all_outputs = [*archive_outputs, index_path]
    if any(path.exists() for path in all_outputs):
        raise ValueError("Evidence output paths must be new; existing files are never overwritten")
    generated_root = study / "evidence-assembly" / "archives"
    if any(path.is_relative_to(study) and not path.is_relative_to(generated_root) for path in all_outputs):
        raise ValueError("An output inside the study must be under evidence-assembly/archives/")
    finalization_paths = {study / finalization[k]["logical_path"][6:] for k in finalization}
    if any(path in finalization_paths for path in all_outputs):
        raise ValueError("Output would overwrite a finalization record")
    if not packets_root.is_dir():
        raise ValueError("Packet root is not a directory")
    if any(path.is_relative_to(packets_root) for path in all_outputs):
        raise ValueError("Outputs cannot be written inside immutable packet scope")
    files = inventory(study, "study", (generated_root, *all_outputs))
    allocations = sorted((study / "runs").glob("*/allocation.json"))
    if not allocations:
        raise ValueError("No run allocations found")
    packet_records = {}
    validations = []
    protected = {record["logical_path"] for record in finalization.values()}
    original_hashes = set()
    expected_exact = {}
    final_mirrors = {}

    for allocation_path in allocations:
        _, allocation = object_record(allocation_path)
        packet = absolute_safe(allocation["packet"])
        if packet.parent != packets_root:
            raise ValueError("Allocation packet must be a direct child of --packets-root")
        expected = allocation["packet_manifest_sha256"]
        if packet.name in packet_records:
            if packet_records[packet.name]["manifest_sha256"] != expected:
                raise ValueError("Contradictory packet allocation hashes")
        else:
            verified, file_hashes = verify_tree(packet, packet / "manifest.json", expected)
            prefix = "packets/" + safe_logical(packet.name)
            packet_files = inventory(packet, prefix)
            if files.keys() & packet_files.keys():
                raise ValueError("Logical packet collision")
            files.update(packet_files)
            protected.update(packet_files)
            expected_exact.update({prefix + "/" + k: v for k, v in file_hashes.items()})
            expected_exact[prefix + "/manifest.json"] = expected
            original_hashes.update(v for k, v in file_hashes.items() if k.startswith("inputs/"))
            packet_records[packet.name] = {"logical_root": prefix, **verified}
            validations.append({"kind": "immutable_packet", "logical_path": prefix + "/manifest.json", **verified})
        assignment = allocation_path.parent / "assignment.txt"
        protected.update("study/" + path.relative_to(study).as_posix() for path in (allocation_path, assignment))
        if sha256(read_exact(assignment)) != allocation["assignment_sha256"]:
            raise ValueError("Run assignment hash mismatch: " + str(assignment))
        method = safe_logical(allocation["method"])
        if "/" in method:
            raise ValueError("Method must be one path component")
        method_manifest = study / "methods" / (method + ".manifest.json")
        if sha256(read_exact(method_manifest)) != allocation["method_manifest_sha256"]:
            raise ValueError("Allocated method manifest changed")
        snapshots = allocation_path.parent / "snapshots"
        if not (snapshots / "final" / "manifest.json").is_file():
            raise ValueError("Run has no frozen final snapshot: " + allocation_path.parent.name)
        for stage in sorted(snapshots.iterdir()):
            if not stage.is_dir():
                raise ValueError("Unexpected file in snapshots directory")
            verified, stage_hashes = verify_tree(stage, stage / "manifest.json")
            logical = "study/" + (stage / "manifest.json").relative_to(study).as_posix()
            expected_exact.update({logical[:-len("manifest.json")] + k: v for k, v in stage_hashes.items()})
            expected_exact[logical] = verified["manifest_sha256"]
            protected.add(logical)
            validations.append({"kind": "frozen_stage", "logical_path": logical, **verified})
        run_prefix = "study/" + allocation_path.parent.relative_to(study).as_posix()
        for logical in files:
            for folder in ("work", "diagnostics"):
                mutable_prefix = run_prefix + "/" + folder + "/"
                if logical.startswith(mutable_prefix):
                    match = run_prefix + "/snapshots/final/" + folder + "/" + logical[len(mutable_prefix):]
                    if match in files:
                        final_mirrors[logical] = match

    for path in sorted((study / "methods").glob("*.manifest.json")):
        method = path.name[:-len(".manifest.json")]
        root = study / "methods" / method
        verified, method_hashes = verify_tree(root, path)
        prefix = "study/methods/" + method + "/"
        expected_exact.update({prefix + k: v for k, v in method_hashes.items()})
        expected_exact["study/methods/" + path.name] = verified["manifest_sha256"]
        protected.update(k for k in files if k.startswith(prefix))
        protected.add("study/methods/" + path.name)
        validations.append({"kind": "frozen_method", "logical_path": "study/methods/" + path.name, **verified})
    source_manifest = study / "incident-source-manifest.json"
    if source_manifest.is_file():
        verified, hashes = verify_tree(study / "incident-source", source_manifest, list_shape=True)
        protected.update(k for k in files if k.startswith("study/incident-source/"))
        original_hashes.update(hashes.values())
        expected_exact.update({"study/incident-source/" + k: v for k, v in hashes.items()})
        expected_exact["study/incident-source-manifest.json"] = verified["manifest_sha256"]
        protected.add("study/incident-source-manifest.json")
        validations.append({"kind": "original_source", "logical_path": "study/incident-source-manifest.json", **verified})

    retained = []
    excluded = []
    blobs = {}
    observations = []
    hash_by_path = {}
    # All bytes are rechecked against inventory signatures before the ZIP is committed.
    initial_signatures = {k: signature(p) for k, p in files.items()}

    def keep(logical, data, mode, **extra):
        safe_logical(logical)
        digest = sha256(data)
        blobs.setdefault(digest, data)
        retained.append({"logical_path": logical, "sha256": digest, "bytes": len(data), "mode": mode, **extra})

    for logical, path in sorted(files.items()):
        data = read_exact(path)
        digest = sha256(data)
        hash_by_path[logical] = digest
        reason = path_exclusion(logical)
        if not reason and logical.startswith("study/publication/") and path.suffix.lower() == ".json":
            try:
                kinds = publication_parts(load_unique_json(data))
                if kinds == {"connector", "other"}:
                    raise ValueError("Mixed publication connector/local-or-metadata record requires explicit separation before assembly: " + logical + " sha256=" + digest)
                if kinds == {"connector"}:
                    reason = "Publication connector response excluded; separate local command receipts and study metadata retained"
            except json.JSONDecodeError:
                if "connector" in path.name.lower():
                    raise ValueError("Unparseable publication connector record: " + logical)
        if not reason and native_executable(data) and digest not in original_hashes:
            reason = "Native executable outside supplied original source excluded"
        if reason:
            if logical in protected:
                raise ValueError("Protected canonical/finalization bytes conflict with exclusion policy; explicit scope resolution required: " + logical + " sha256=" + digest)
            excluded.append({"logical_path": logical, "sha256": digest, "bytes": len(data), "reason": reason})
            continue
        replacement = final_mirrors.get(logical) if logical not in protected else None
        if replacement:
            replacement_hash = sha256(read_exact(files[replacement]))
            if digest == replacement_hash:
                excluded.append({"logical_path": logical, "sha256": digest, "bytes": len(data), "reason": "Mutable copy is byte-identical to frozen final snapshot", "replacement_logical_path": replacement})
                continue
            observations.append({"logical_path": logical, "reason": "Mutable bytes differ from final snapshot; both versions retained", "final_snapshot_logical_path": replacement})
        derived = diagnostic_provenance(data, logical)
        if derived:
            if logical in protected:
                raise ValueError("Protected canonical/finalization bytes conflict with web-capture exclusion; explicit scope resolution required: " + logical + " sha256=" + digest)
            replacement_path = "provenance/" + logical
            transformed, omissions = derived
            keep(replacement_path, transformed, 0o444, original_logical_path=logical, original_sha256=digest, original_bytes_included=False, transformation="web_capture_provenance")
            excluded.append({"logical_path": logical, "sha256": digest, "bytes": len(data), "original_bytes_included": False, "reason": "Confirmed third-party webpage capture bodies excluded; any unmodified surrounding JSON bytes preserved", "replacement_logical_path": replacement_path, "web_captures": omissions})
        else:
            keep(logical, data, initial_signatures[logical][4])

    by_excluded = {row["logical_path"]: row for row in excluded}
    # Resolve aliases through page-provenance replacements without implying exact reconstruction.
    for row in excluded:
        target = row.get("replacement_logical_path")
        if target in by_excluded:
            destination = by_excluded[target]
            if "replacement_logical_path" not in destination:
                row.pop("replacement_logical_path")
                row["reason"] += "; its snapshot copy is also excluded by policy"
            else:
                row["replacement_logical_path"] = destination["replacement_logical_path"]
                row["replacement_is_provenance_only"] = True
                row["original_bytes_included"] = False
    for logical, expected in expected_exact.items():
        if hash_by_path.get(logical) != expected:
            raise ValueError("Verified immutable bytes changed before packaging: " + logical)
    retained_by_path = {row["logical_path"]: row for row in retained}
    for logical in protected:
        row = retained_by_path.get(logical)
        if row is None or row["sha256"] != hash_by_path.get(logical):
            raise ValueError("Required protected file was not retained exactly: " + logical)
    for label, record in finalization.items():
        row = retained_by_path.get(record["logical_path"])
        if row is None or (row["sha256"], row["bytes"]) != (record["sha256"], record["bytes"]):
            raise ValueError(label + " record was not retained exactly as validated by the finalization gate")
    for logical, path in files.items():
        if signature(path) != initial_signatures[logical]:
            raise ValueError("Source changed during assembly: " + logical)
    retained.sort(key=lambda row: row["logical_path"])
    if len({r["logical_path"] for r in retained}) != len(retained):
        raise ValueError("Derived logical path collision")
    manifest = {"schema": SCHEMA, "archive_encoding": ARCHIVE_ENCODING, "hash_algorithm": "sha256", "blob_path": "blobs/sha256/{sha256}", "study_name": study.name, "scope": {"study_logical_root": "study", "packet_logical_roots": sorted(packet_records), "generated_outputs_are_not_inputs": True, "generated_directory_excluded_from_input_scope": "study/evidence-assembly/archives/", "selection_and_final_results_are_operator_supplied_records": True}, "finalization": finalization, "packet_records": packet_records, "validations": validations, "files": retained, "exclusions": excluded, "observations": observations, "limits": ["Assembly proves retained byte identity and declared scope, not model execution, evaluator correctness, or absence of transient external effects.", "Selection/final-results JSON presence is validated without interpreting or inventing their study-specific schema; --finalize is the operator's assertion that the reserve is exposed and the study complete.", "Web capture identification is conservative: observed tool-result headers or wordlim markers inside diagnostics; unknown marker-free formats require review.", "Excluded web capture bodies, private supplied documents, authentication data, environments and connector responses cannot be reconstructed from this archive."]}
    if part_output is not None:
        manifest["archive_volume_count"] = 2
    manifest_bytes = canonical_json(manifest)
    note = ("EXACT-BYTE STUDY EVIDENCE\n\nRead manifest.json for the sorted logical file inventory, SHA-256, length and mode.\nFor each manifest.files row, verify blobs/sha256/<sha256> against its digest and\nwrite its exact bytes to logical_path under a new empty reconstruction directory.\nReject absolute paths, backslashes, empty components, dots, parent traversal,\ncolon components, symlinks, duplicate paths and non-regular archive members.\nThe bundled assembler's restore() performs those checks; it does not execute files.\n\nStudy records live under study/. Only packets named in run allocations live under\npackets/. The original manifests remain exact retained files. All frozen stages,\noriginal/corrected assessments and raw writer artifacts remain independently named.\n\nmanifest.exclusions gives each omitted source file's exact SHA-256, length and reason.\nByte-identical mutable copies can be reconstructed from their matching final\nsnapshot; restore() materializes only manifest.files, so recreating such aliases\nis optional. A replacement marked provenance-only cannot recover an omitted page.\nDerived provenance/ diagnostics preserve the original bytes outside the replaced\nJSON page strings and record exact original-file, encoded-slice and text hashes\nplus source URLs. No page bodies are included in these records.\n\nZIP entries use fixed timestamps and fixed member metadata with DEFLATE level 9.\nThe manifest and index record the Python and zlib producer versions. Matching\ninputs reproduce ZIP bytes with the same producer; cross-version compressed-byte\nidentity is not assumed. Uncompressed retained bytes keep their exact hashes.\nThe companion .index.json hashes this ZIP and each non-blob member; blobs hash themselves.\nThe index is external because a ZIP cannot contain its own final hash.\n").encode("utf-8")
    if part_output is not None:
        note += ("\nTWO ORDINARY ZIP VOLUMES\nThe primary ZIP contains this note, the global manifest and all other metadata.\nBlob members are distributed between the primary and second ZIP, without duplicates.\nVerify both entries in the companion index archives list before importing the\nprimary bundled helper. Call restore(primary, destination, parts=[second]) or\nrun: python assemble.py restore PRIMARY DESTINATION --part SECOND\nBoth volumes are required; their union reconstructs every manifest.files row.\n").encode("utf-8")
    members = {"manifest.json": manifest_bytes, "RECONSTRUCT.txt": note}
    members.update(bundled_assembler_members())
    members.update({"blobs/sha256/" + h: data for h, data in blobs.items()})
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".evidence-", suffix=".zip", dir=output.parent)
    os.close(fd)
    temp_path = Path(temp_name)
    staged_paths = [temp_path]
    try:
        write_archive(temp_path, members)
        if part_output is not None:
            # Measure actual compressed entries before assigning blobs. Metadata stays primary.
            with zipfile.ZipFile(temp_path) as measured:
                weights = {info.filename: info.compress_size + 76 + 2 * len(info.filename.encode("utf-8"))
                           for info in measured.infolist()}
            groups = [{name: data for name, data in members.items() if not name.startswith("blobs/")}, {}]
            sizes = [22 + sum(weights[name] for name in groups[0]), 22]
            for name in sorted((name for name in members if name.startswith("blobs/")),
                               key=lambda name: (-weights[name], name)):
                selected = min(range(2), key=lambda i: (sizes[i], i))
                groups[selected][name] = members[name]
                sizes[selected] += weights[name]
            fd, second_name = tempfile.mkstemp(prefix=".evidence-", suffix=".zip", dir=output.parent)
            os.close(fd)
            staged_paths.append(Path(second_name))
            for staged, group in zip(staged_paths, groups):
                write_archive(staged, group)
        archive_payloads = [read_exact(staged) for staged in staged_paths]
        if part_output is not None and any(len(data) > MAX_VOLUME_BYTES for data in archive_payloads):
            raise ValueError("Two-volume output exceeds the 11000000-byte per-volume limit: "
                             + ", ".join(str(len(data)) for data in archive_payloads))
        archive_bytes = archive_payloads[0]
        index = {"schema": SCHEMA + "-index", "archive_encoding": ARCHIVE_ENCODING, "archive_sha256": sha256(archive_bytes), "archive_bytes": len(archive_bytes), "archive_metadata": [{"logical_path": name, "sha256": sha256(data), "bytes": len(data)} for name, data in sorted(members.items()) if not name.startswith("blobs/")], "retained_logical_files": len(retained), "unique_blobs": len(blobs), "retained_logical_bytes": sum(r["bytes"] for r in retained), "unique_blob_bytes": sum(map(len, blobs.values())), "excluded_files": len(excluded), "exclusions_by_reason": {reason: sum(r["reason"] == reason for r in excluded) for reason in sorted({r["reason"] for r in excluded})}, "verified_manifest_count": len(validations), "reconstruction_note": "RECONSTRUCT.txt", "scope": "Named study plus allocation-referenced immutable packets only"}
        if part_output is not None:
            index["archives"] = [{"name": path.name, "sha256": sha256(data), "bytes": len(data)}
                                 for path, data in zip(archive_outputs, archive_payloads)]
        index_fd, index_name = tempfile.mkstemp(prefix=".evidence-", suffix=".index.json", dir=output.parent)
        temp_index = Path(index_name)
        try:
            with os.fdopen(index_fd, "wb") as stream:
                stream.write(canonical_json(index))
            if part_output is None:
                publish_pair(temp_path, output, temp_index, index_path)
            else:
                publish_outputs([*zip(staged_paths, archive_outputs), (temp_index, index_path)])
        finally:
            temp_index.unlink(missing_ok=True)
    finally:
        for staged in staged_paths:
            staged.unlink(missing_ok=True)
    return index


def write_archive(path, members):
    """Write ordinary ZIP members using the recorded deterministic encoding."""
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for name, data in sorted(members.items()):
            entry = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, data, compresslevel=9)


def publish_pair(staged_zip, output, staged_index, index_path):
    """Create both outputs without clobbering; roll back only this call's links."""
    publish_outputs(((staged_zip, output), (staged_index, index_path)))


def publish_outputs(pairs):
    """Publish every staged volume and index, rolling back only this call's links."""
    created = []
    try:
        for source, destination in pairs:
            before = source.lstat()
            os.link(source, destination, follow_symlinks=False)
            created.append((destination, (before.st_dev, before.st_ino)))
    except BaseException:
        for destination, identity in reversed(created):
            try:
                current = destination.lstat()
                if (current.st_dev, current.st_ino) == identity:
                    destination.unlink()
            except FileNotFoundError:
                pass
        raise


def restore(archive_path, destination, parts=()):
    """Verify all supplied ordinary ZIP volumes before materializing retained files."""
    archive_paths = [absolute_safe(archive_path), *(absolute_safe(path) for path in parts)]
    if len(set(archive_paths)) != len(archive_paths):
        raise ValueError("Duplicate evidence volume")
    destination = absolute_safe(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Reconstruction destination must be empty")
    with ExitStack() as stack:
        archives = []
        member_archives = {}
        for volume_number, path in enumerate(archive_paths):
            regular(path)
            archive = stack.enter_context(zipfile.ZipFile(path))
            archives.append(archive)
            for info in archive.infolist():
                safe_logical(info.filename)
                mode = info.external_attr >> 16
                if info.is_dir() or (stat.S_IFMT(mode) not in (0, stat.S_IFREG)):
                    raise ValueError("Unsafe archive member type")
                if info.filename in member_archives:
                    raise ValueError("Duplicate archive member across evidence volumes: " + info.filename)
                if volume_number and (not info.filename.startswith("blobs/sha256/")
                                      or not SHA.fullmatch(info.filename[len("blobs/sha256/"):])):
                    raise ValueError("Secondary evidence volumes may contain only blob members")
                member_archives[info.filename] = archive
        manifest = load_unique_json(archives[0].read("manifest.json"))
        if manifest.get("schema") != SCHEMA:
            raise ValueError("Unknown evidence schema")
        expected_volumes = manifest.get("archive_volume_count", 1)
        if type(expected_volumes) is not int or expected_volumes not in (1, 2):
            raise ValueError("Unsupported evidence volume count")
        if len(archives) != expected_volumes:
            raise ValueError("Expected " + str(expected_volumes) + " evidence volumes; received " + str(len(archives)))
        rows = manifest["files"]
        paths = [safe_logical(r["logical_path"]) for r in rows]
        if len(set(paths)) != len(paths):
            raise ValueError("Duplicate reconstruction path")
        paths_set = set(paths)
        for path in paths:
            if any(str(parent) in paths_set for parent in PurePosixPath(path).parents):
                raise ValueError("File/directory reconstruction collision")
        materialized = []
        for row in rows:
            digest = row["sha256"]
            if not isinstance(digest, str) or not SHA.fullmatch(digest):
                raise ValueError("Invalid blob digest")
            member = "blobs/sha256/" + digest
            if member not in member_archives:
                raise ValueError("Missing required manifest blob: " + digest)
            data = member_archives[member].read(member)
            if len(data) != row["bytes"] or sha256(data) != digest:
                raise ValueError("Blob identity mismatch")
            materialized.append((row, data))
        destination.mkdir(parents=True, exist_ok=True)
        for row, data in materialized:
            path = destination.joinpath(*row["logical_path"].split("/"))
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as stream:
                stream.write(data)
            # Restore ordinary mode bits only; never introduce setuid/setgid/sticky bits.
            path.chmod(row.get("mode", 0o644) & 0o777)
        return len(materialized)


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--finalize", action="store_true", help="Required assertion: reserve exposed and all final records complete")
    result.add_argument("--study", required=True)
    result.add_argument("--packets-root", required=True, help="Only directly referenced immutable packet children are read")
    result.add_argument("--selection-record", required=True, help="Existing nonempty JSON object inside the study; no inferred filename/schema")
    result.add_argument("--final-results-record", required=True, help="Distinct existing nonempty JSON object inside the study")
    result.add_argument("--output", required=True, help="Evidence ZIP; companion index uses .index.json")
    result.add_argument("--part-output", help="Optional second ordinary ZIP in the primary output directory; both capped at 11000000 bytes")
    return result


if __name__ == "__main__":
    try:
        if len(sys.argv) > 1 and sys.argv[1] == "restore":
            restore_parser = argparse.ArgumentParser(description="Restore retained evidence from verified ordinary ZIP volumes")
            restore_parser.add_argument("archive")
            restore_parser.add_argument("destination")
            restore_parser.add_argument("--part", action="append", default=[])
            restore_args = restore_parser.parse_args(sys.argv[2:])
            print(json.dumps({"restored_files": restore(restore_args.archive, restore_args.destination, parts=restore_args.part)}))
        else:
            print(json.dumps(assemble(parser().parse_args()), sort_keys=True, indent=2))
    except (ValueError, KeyError, OSError, json.JSONDecodeError, zipfile.BadZipFile) as error:
        print("Evidence assembly refused: " + str(error), file=sys.stderr)
        sys.exit(2)
